resource_manifest_version "44febabe-d386-4d18-afbe-5e627f4af937"

Discription "Tablet"

Version "0.2"

ui_page "nui/ui.html"

files {
    "nui/ui.html",
    "nui/material-icons.ttf",
    "nui/material-icons.css",
    "nui/loadscreen.jpg",
    "nui/fancy-crap.css",
    "nui/fancy-crap.js",
    "nui/jquery.min/js",
    "nui/html/news.html",
    "nui/html/laws.html",
    "nui/html/hotties.html",
    "nui/html/youtube.html",
    "nui/html/spotify.html",
    "nui/html/snake.html",
    "nui/html/fuckyouitsdope.png",
    "nui/html/jobsfordummies.html",
    "nui/html/rulesforassholes.html",
    "nui/bootstrap.min.css",
    "nui/html/opencad.html"
}

client_script "client.lua"
